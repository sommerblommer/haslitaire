main :: IO ()
main = putStr "bruh"  
